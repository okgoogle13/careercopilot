
  # Career Copilot

  This is a code bundle for Career Copilot. The original project is available at https://www.figma.com/design/U0hT1W6S732sbBk3ghOZNW/Career-Copilot.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  